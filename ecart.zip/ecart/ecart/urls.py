
from django.contrib import admin
from django.urls import path
from mainApp import views as mainApp
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',mainApp.homePage),
    path('shop/<str:mc>/<str:sc>/<str:br>/',mainApp.shopPage),
    path('filter/<str:mc>/<str:sc>/<str:br>/<str:filter>/',mainApp.filterPage),
    path('price-filter/<str:mc>/<str:sc>/<str:br>/',mainApp.pricefilterPage),
    path('search/',mainApp.searchPage),
    path('single-product/<int:id>/',mainApp.singleProductPage),
    path('cart/',mainApp.cartPage),
    path('checkout/',mainApp.checkoutPage),
    path('contact/',mainApp.contactPage),
    path('login/',mainApp.loginPage),
    path('logout/',mainApp.logoutPage),
    path('signup/',mainApp.signupPage),
    path('profile/',mainApp.profilePage),
    path('add-to-cart/<int:num>/',mainApp.addToCartPage),
    path('update-profile/',mainApp.updateProfilePage),

]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
