from django.db import models

# Create your models here.
class Maincategory(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=20)

    def __str__(self):
        return self.name
    
class Subcategory(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=20)

    def __str__(self):
        return self.name

class Brands(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=20)

    def __str__(self):
        return self.name

class Product(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=20)
    maincategory=models.ForeignKey(Maincategory,on_delete=models.CASCADE)
    subcategory=models.ForeignKey(Subcategory,on_delete=models.CASCADE)
    brand=models.ForeignKey(Brands,on_delete=models.CASCADE)
    color=models.CharField(max_length=30)
    size=models.CharField(max_length=30)
    baseprice=models.IntegerField()
    discount=models.IntegerField()
    finalprice=models.IntegerField()
    stock=models.BooleanField(default=True)
    description=models.TextField()
    pic1=models.ImageField(upload_to="products")
    pic2=models.ImageField(upload_to="products",default=None,null=True,blank=True)
    pic3=models.ImageField(upload_to="products",default=None,null=True,blank=True)
    pic4=models.ImageField(upload_to="products",default=None,null=True,blank=True)

    def __str__(self):
        return self.name
    
contactStatus=((1,"Active"),(2,"Done"))
class contact(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    email=models.EmailField(max_length=100)
    phone=models.CharField(max_length=20)
    subject=models.CharField(max_length=200)
    message=models.TextField()
    status=models.IntegerField(choices=contactStatus,default=1)

    def __str__(self):
       return str(self.id)+ "/" +self.name+ " /"+self.email+ " /"+self.subject
    
class Buyer(models.Model):
    id= models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    username=models.CharField(max_length=30,default="")
    email=models.EmailField(max_length=30)
    phone=models.CharField(max_length=30)
    addressline1=models.CharField(max_length=30,default="",null=True,blank=True)
    addressline2=models.CharField(max_length=30,default="",null=True,blank=True)
    addressline3=models.CharField(max_length=30,default="",null=True,blank=True)
    pin=models.CharField(max_length=30,default="",null=True,blank=True)
    city=models.CharField(max_length=30,default="",null=True,blank=True)
    state=models.CharField(max_length=30,default="",null=True,blank=True)
    pic=models.ImageField(max_length=30,default="",null=True,blank=True)

    def __str__(self):
        return self.username+"/"+self.name+"/"+self.email