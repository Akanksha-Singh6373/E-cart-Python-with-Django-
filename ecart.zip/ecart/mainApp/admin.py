from django.contrib import admin
from .models import *
   
admin.site.register((Maincategory,Subcategory,Brands,Product,Buyer,contact))


