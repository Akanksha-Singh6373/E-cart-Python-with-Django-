from django.shortcuts import render ,HttpResponseRedirect
from .models import *
from django.db.models import Q
from django.contrib.auth.models import User
from django.contrib import auth
from django.conf import settings
from django.contrib import messages


from django.contrib.auth.decorators import login_required 


# Create your views here.
def homePage(Request):
    data=Product.objects.all().order_by("-id")[0:8]
    return render(Request,'index.html',{'data':data})

def shopPage(Request,mc,sc,br):
    if(mc=="All" and sc=="All" and br=="All"):
        data = Product.objects.all().order_by("-id")
    elif(mc!="All" and sc=="All" and br=="All"):
        data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc)).order_by("-id")
    elif(mc=="All" and sc!="All" and br=="All"):
        data = Product.objects.filter(subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
    elif(mc=="All" and sc=="All" and br!="All"):
        data = Product.objects.filter(brand=Brands.objects.get(name=br)).order_by("-id")
    elif(mc!="All" and sc!="All" and br=="All"):
        data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
    elif(mc!="All" and sc=="All" and br!="All"):
        data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br)).order_by("-id")
    elif(mc=="All" and sc!="All" and br!="All"):
        data = Product.objects.filter(brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
    else:
        data = Product.objects.filter(Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
   
   
    maincategories=Maincategory.objects.all()
    subcategories=Subcategory.objects.all()
    brands=Brands.objects.all()
    return render(Request,"shop.html",{'data':data,'maincategories':maincategories,'subcategories':subcategories,'brands':brands,'mc':mc,'sc':sc,'br':br})

def filterPage(Request,mc,sc,br,filter):
    if(filter=="Latest"):
        if(mc=="All" and sc=="All" and br=="All"):
           data = Product.objects.all().order_by("-id")
        elif(mc!="All" and sc=="All" and br=="All"):
            data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc)).order_by("-id")
        elif(mc=="All" and sc!="All" and br=="All"):
            data = Product.objects.filter(subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
        elif(mc=="All" and sc=="All" and br!="All"):
            data = Product.objects.filter(brand=Brands.objects.get(name=br)).order_by("-id")
        elif(mc!="All" and sc!="All" and br=="All"):
            data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
        elif(mc!="All" and sc=="All" and br!="All"):
            data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br)).order_by("-id")
        elif(mc=="All" and sc!="All" and br!="All"):
            data = Product.objects.filter(brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
        else:
            data = Product.objects.filter(Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("-id")
    elif(filter=="LTOH"):
        if(mc=="All" and sc=="All" and br=="All"):
            data = Product.objects.all().order_by("finalprice")
        elif(mc!="All" and sc=="All" and br=="All"):
            data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc)).order_by("finalprice")
        elif(mc=="All" and sc!="All" and br=="All"):
            data = Product.objects.filter(subcategory=Subcategory.objects.get(name=sc)).order_by("finalprice")
        elif(mc=="All" and sc=="All" and br!="All"):
            data = Product.objects.filter(brand=Brands.objects.get(name=br)).order_by("finalprice")
        elif(mc!="All" and sc!="All" and br=="All"):
            data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),subcategory=Subcategory.objects.get(name=sc)).order_by("finalprice")
        elif(mc!="All" and sc=="All" and br!="All"):
            data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br)).order_by("finalprice")
        elif(mc=="All" and sc!="All" and br!="All"):
            data = Product.objects.filter(brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("finalprice")
        else:
            data = Product.objects.filter(Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("finalprice")
    else:
        if(mc=="All" and sc=="All" and br=="All"):
           data = Product.objects.all().order_by("-finalprice")
        elif(mc!="All" and sc=="All" and br=="All"):
           data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc)).order_by("-finalprice")
        elif(mc=="All" and sc!="All" and br=="All"):
           data = Product.objects.filter(subcategory=Subcategory.objects.get(name=sc)).order_by("-finalprice")
        elif(mc=="All" and sc=="All" and br!="All"):
           data = Product.objects.filter(brand=Brands.objects.get(name=br)).order_by("-finalprice")
        elif(mc!="All" and sc!="All" and br=="All"):
           data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),subcategory=Subcategory.objects.get(name=sc)).order_by("-finalprice")
        elif(mc!="All" and sc=="All" and br!="All"):
           data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br)).order_by("-finalprice")
        elif(mc=="All" and sc!="All" and br!="All"):
           data = Product.objects.filter(brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("-finalprice")
        else:
           data = Product.objects.filter(Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc)).order_by("-finalprice")
    maincategories=Maincategory.objects.all()
    subcategories=Subcategory.objects.all()
    brands=Brands.objects.all()

    return render(Request,"shop.html",{'data':data,'maincategories':maincategories,'subcategories':subcategories,'brands':brands,'mc':mc,'sc':sc,'br':br})

def pricefilterPage(Request,mc,sc,br):
    option = Request.POST.get("price")
    if(option=="1"):
        min=0
        max=100000
    elif(option=="2"):
        min=0
        max=1000
    elif(option=="3"):
        min=1000
        max=2000
    elif(option=="4"):
        min=2000
        max=3000
    elif(option=="5"):
        min=3000
        max=4000
    elif(option=="6"):
        min=4000
        max=5000
    elif(option=="7"):
        min=5000
        max=100000
    if(mc=="All" and sc=="All" and br=="All"):
        data = Product.objects.filter(finalprice__gte=min,finalprice__lte=max).order_by("-id")
    elif(mc!="All" and sc=="All" and br=="All"):
        data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    elif(mc=="All" and sc!="All" and br=="All"):
        data = Product.objects.filter(subcategory=Subcategory.objects.get(name=sc),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    elif(mc=="All" and sc=="All" and br!="All"):
        data = Product.objects.filter(brand=Brands.objects.get(name=br),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    elif(mc!="All" and sc!="All" and br=="All"):
        data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),subcategory=Subcategory.objects.get(name=sc),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    elif(mc!="All" and sc=="All" and br!="All"):
        data = Product.objects.filter(maincategory=Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    elif(mc=="All" and sc!="All" and br!="All"):
        data = Product.objects.filter(brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    else:
        data = Product.objects.filter(Maincategory.objects.get(name=mc),brand=Brands.objects.get(name=br),subcategory=Subcategory.objects.get(name=sc),finalprice__gte=min,finalprice__lte=max).order_by("-id")
    maincategories=Maincategory.objects.all()
    subcategories=Subcategory.objects.all()
    brands=Brands.objects.all()
    return render(Request,"shop.html",{'data':data,'maincategories':maincategories,'subcategories':subcategories,'brands':brands,'mc':mc,'sc':sc,'br':br})



def searchPage(Request):
    if(Request.method=="POST"):
        search=Request.POST.get("search")
        data=Product.objects.filter(Q(name__contains=search)|Q(color__contains=search)|Q(size__contains=search)|Q(stock__contains=search)|Q(description__contains=search))
        maincategories=Maincategory.objects.all()
        subcategories=Subcategory.objects.all()
        brands=Brands.objects.all()
        return render(Request,"shop.html",{'data':data,'maincategories':maincategories,'subcategories':subcategories,'brands':brands,'mc':'All','sc':'All','br':'All'})    
    else:
        return HttpResponseRedirect("/")
        
def singleProductPage(Request,id):
    data=Product.objects.get(id=id)
    relatedProducts=Product.objects.filter(maincategory=Maincategory.objects.get(name=data.maincategory))
    return render(Request,"detail.html",{'data':data,'relatedProducts':relatedProducts})

def addToCartPage(Request,num):
    p=Product.objects.get(id=num)
    if(p):
        cart=Request.session.get("cart",None)
        if(cart):
            if(str(num) in cart):
                return HttpResponseRedirect("/cart/")
            else:
                cart.setdefault(str(num),{'id':p.id,'name':p.name,'brands':p.brand,'color':p.color,'size':p.size,'price':p.finalprice,'qty':1,'total':p.finalprice,'pic':p.pic1.url})
        else:
            cart={str(num):{'id':p.id,'name':p.name,'brands':p.brand,'color':p.color,'size':p.size,'price':p.finalprice,'qty':1,'total':p.finalprice,'pic':p.pic1.url}}
        Request.session['cart']=cart
        subtotal=0
        count=0
        for key,values in cart.items():
            subtotal=subtotal+values['total']
            count=count +values['qty']
        if(subtotal>0 and subtotal<1000):
            shipping=150
        else:
            shipping=0
        total=subtotal + shipping
        Request.session['cart']=cart
        Request.session['subtotal']=subtotal
        Request.session['shipping']=shipping
        Request.session['total']=total
        Request.session['count']=count
        Request.session.set_expiry(60*60*24*30)
        return HttpResponseRedirect("/cart/")
    else:
        return HttpResponseRedirect("/shop/All/All/All/")

def cartPage(Request):
    cart=Request.session.get("cart",None)
    print(cart,"\n\n\n\n\n\n")
    return render(Request,"cart.html",{'cart':cart})

def checkoutPage(Request):
    return render(Request,"checkout.html")
 
def contactPage(Request):
    if(Request.method=="POST"):
        c=contact()
        c.name=Request.POST.get("name")
        c.email=Request.POST.get("email")
        c.phone=Request.POST.get("phone")
        c.subject=Request.POST.get("subject")
        c.message=Request.POST.get("message")
        c.save()
        messages.success(Request,"Thanks To Share Query With Us!!!! Our Team Will Contact You Soon")
    return render(Request,'contact.html')

def loginPage(Request):
    if(Request.method=="POST"):
        username=Request.POST.get("username")
        password=Request.POST.get("password")
        user=auth.authenticate(username=username,password=password)
        if(user is None):
            messages.eror(Request,"invalid Usrname or Password!!!!")
        else:
            auth.login(Request,user)
            if(user.is_superuser):
                return HttpResponseRedirect("/admin/")
            else:
                return HttpResponseRedirect("/profile/")
    return render(Request,'login.html')

def signupPage(Request):
    if(Request.method=="POST"):
        if(Request.POST.get("password")!=Request.POST.get("cpassword")):
            messages.error(Request,"Password and Confirm Password Doesn't Matched")
        else:
            try:
                user=User.objects.create(username=Request.POST.get("username"))
                user.set_password(Request.POST.get("password"))
                user.save()

                b=Buyer()
                b.name=Request.POST.get("name")
                b.username=Request.POST.get("username")
                b.email=Request.POST.get("email")
                b.phone=Request.POST.get("phone")
                b.save()
                return HttpResponseRedirect("/login/")
            except:
                messages.error(Request,"Username Already Taken!!!")
    return render(Request,'signup.html')

@login_required(login_url="/login/")
def profilePage(Request):
    user=User.objects.get(username=Request.user.username)
    if(user.is_superuser):
        return HttpResponseRedirect("/admin/")
    else:
        buyer=Buyer.objects.get(username=Request.user.username)
        return render(Request,"profile.html",{'data':buyer})

@login_required(login_url="/login/")
def updateProfilePage(Request):
    user=User.objects.get(username=Request.user.username)
    if(user.is_superuser):
        return HttpResponseRedirect("/admin/")
    else:
        buyer=Buyer.objects.get(username=Request.user.username)
        if(Request.method=="POST"):
            buyer.name=Request.POST.get("name")
            buyer.email=Request.POST.get("email")
            buyer.phone=Request.POST.get("phone")
            buyer.addressline1=Request.POST.get("addressline1")
            buyer.addressline2=Request.POST.get("addressline2")
            buyer.addressline3=Request.POST.get("addressline3")
            buyer.pin=Request.POST.get("pin")
            buyer.city=Request.POST.get("city")
            buyer.state=Request.POST.get("state")
            if(Request.FILES.get("pic")!=""):
                buyer.pic = Request.FILES.get("pic")
            buyer.save()
            return HttpResponseRedirect("/profile/",{'data':buyer})

def logoutPage(Request):
    auth.logout(Request)
    return HttpResponseRedirect("/login/")